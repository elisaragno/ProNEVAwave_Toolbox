function varargout = ProNEVAwave_GUI(varargin)
% PRONEVAWAVE_GUI MATLAB code for ProNEVAwave_GUI.fig
%      PRONEVAWAVE_GUI, by itself, creates a new PRONEVAWAVE_GUI or raises the existing
%      singleton*.
%
%      H = PRONEVAWAVE_GUI returns the handle to a new PRONEVAWAVE_GUI or the handle to
%      the existing singleton*.
%
%      PRONEVAWAVE_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PRONEVAWAVE_GUI.M with the given input arguments.
%
%      PRONEVAWAVE_GUI('Property','Value',...) creates a new PRONEVAWAVE_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ProNEVAwave_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ProNEVAwave_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ProNEVAwave_GUI

% Last Modified by GUIDE v2.5 18-Apr-2021 08:35:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ProNEVAwave_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ProNEVAwave_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ProNEVAwave_GUI is made visible.
function ProNEVAwave_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ProNEVAwave_GUI (see VARARGIN)

% Choose default command line output for ProNEVAwave_GUI
handles.output = hObject;

% SET DEFAULT VALUES

handles.iterationsText.String = '10000';                                % Set Number of Iterations
handles.RUNspec.maxIT  = str2double(handles.iterationsText.String);

handles.BurninText.String = '9000';                                       % Set Number of Burn-In
handles.RUNspec.brn = str2double(handles.BurninText.String);

handles.ChainText.String = '3';                                        % Set Number of Chains
handles.RUNspec.Nchain = str2double(handles.ChainText.String);

handles.RPtext.String = '100';                                          % Set Return Period
handles.RUNspec.RP = str2double(handles.RPtext.String);

guidata(hObject, handles);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ProNEVAwave_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ProNEVAwave_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%-------------------------------------------------------------------
%                    (1) BROWSE DATA  
%---------------------------------------------------------------------
% --- Executes on button press in BrowseData.
function BrowseData_Callback(hObject, eventdata, handles)
% Get the file path
[FileName,FilePath] = uigetfile('*.txt','Select the text file to process','Multiselect','off'); 
% save it
ExPath = fullfile(FilePath, FileName);
% Write to a text editor for user
set(handles.datapath,'string',ExPath);              
% SAVE OBSERVATIONS
handles.OBS = load(ExPath);

% A few checks: this package works for two variables only
if size(handles.OBS,2) ~= 1
msgbox({'........................................',...
    '........................................',...
    'Select single vector',...
    '........................................',...
    '........................................'});
end

% Update handles structure
guidata(hObject, handles);

% Display path
function datapath_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function datapath_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%--------------------------------------------------------
%                      (2) SELECT DISTRIBUTION
%--------------------------------------------------------
% --- Executes on button press in GEVbutton.
function GEVbutton_Callback(hObject, eventdata, handles)

if get(hObject,'Value')  %returns toggle state of GEV check box
    handles.RUNspec.DISTR.Type = 'GEV';
    % Unable selection of the other variable
    set(handles.GPbutton,'enable','off');
    
    set(handles.Ucheck,'enable','off');
    set(handles.Utext,'enable','off');
    set(handles.Th_q,'enable','off');
    set(handles.Qtext,'enable','off');
    set(handles.PeakMeanDistText,'enable','off');
    set(handles.NobsText,'enable','off');
        
elseif ~get(hObject,'Value')
    set(handles.GPbutton,'enable','on');
    
    set(handles.Ucheck,'enable','on');
    set(handles.Utext,'enable','on');
    set(handles.Th_q,'enable','on');
    set(handles.Qtext,'enable','on');
    set(handles.PeakMeanDistText,'enable','on');
    set(handles.NobsText,'enable','on');
end

% Update handles structure
guidata(hObject, handles);  

% --- Executes on button press in GPbutton.
function GPbutton_Callback(hObject, eventdata, handles)

if get(hObject,'Value')  %returns toggle state of GEV check box
    handles.RUNspec.DISTR.Type = 'GP';
    % Unable selection of the other variable
    set(handles.GEVbutton,'enable','off');
elseif ~get(hObject,'Value')
    set(handles.GEVbutton,'enable','on');
end
% Update handles structure
guidata(hObject, handles); 

%-----------------------------------------------------------------
%                    (2.1) additional info if GP
%----------------------------------------------------------------

% ----> INSERT THRESHOLD
% --- Executes on button press in Ucheck.
function Ucheck_Callback(hObject, eventdata, handles)

if get(hObject,'Value')  %returns toggle state of GEV check box
    handles.RUNspec.Utype = 'U';
    % Unable selection of the other variable
    set(handles.Th_q,'enable','off');
    set(handles.Qtext,'enable','off');
elseif ~get(hObject,'Value')
    set(handles.Th_q,'enable','on');
    set(handles.Qtext,'enable','on');
end
% Update handles structure
guidata(hObject, handles); 

% read threshold
function Utext_Callback(hObject, eventdata, handles)
handles.RUNspec.u = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure

% --- Executes during object creation, after setting all properties.
function Utext_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% -----> INSERT QUANTILE

% --- Executes on button press in Th_q.
function Th_q_Callback(hObject, eventdata, handles)
if get(hObject,'Value')  %returns toggle state of GEV check box
    handles.RUNspec.Utype = 'Th';
    % Unable selection of the other variable
    set(handles.Ucheck,'enable','off');
    set(handles.Utext,'enable','off');
    
    
elseif ~get(hObject,'Value')
    set(handles.Ucheck,'enable','on');
    set(handles.Utext,'enable','on');
end
% Update handles structure
guidata(hObject, handles);

% Read quantile
function Qtext_Callback(hObject, eventdata, handles)

handles.RUNspec.THp = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure


% --- Executes during object creation, after setting all properties.
function Qtext_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% -----> INSERT MEAN PEAK DISTANCE
function PeakMeanDistText_Callback(hObject, eventdata, handles)

handles.RUNspec.MinPeaksDist = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure

% --- Executes during object creation, after setting all properties.
function PeakMeanDistText_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% ----> INSERT NUMBER OF OBSERVATIONS PER YEAR
function NobsText_Callback(hObject, eventdata, handles)
handles.RUNspec.NobsY = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure


% --- Executes during object creation, after setting all properties.
function NobsText_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%--------------------------------------------------------------------------
%                                (3) DEFINED HS MAX 
%------------------------------------------------------------------------
% ----------------------------- USER DEFINED ----------------------------

% --- Executes on button press in UserDefined.
function UserDefined_Callback(hObject, eventdata, handles)

if get(hObject,'Value')  %returns toggle state of limit on hs check box
    handles.RUNspec.wave.limit = 'UserDef';
    % Unable selection of the other variable
    set(handles.depthlimitbox,'enable','off');
    
    set(handles.BetaText,'enable','off');
    set(handles.TwaveText,'enable','off');
    set(handles.DepthText,'enable','off');
    
elseif ~get(hObject,'Value')
    set(handles.depthlimitbox,'enable','on');
    
    set(handles.BetaText,'enable','on');
    set(handles.TwaveText,'enable','on');
    set(handles.DepthText,'enable','on');
end
% Update handles structure
guidata(hObject, handles);

% READ HS MAX
function Hsmax_box_Callback(hObject, eventdata, handles)
handles.RUNspec.wave.Hs_mxmx = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure


% --- Executes during object creation, after setting all properties.
function Hsmax_box_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ------------------------- DEPTH LIMITED-------------------------------

% --- Executes on button press in depthlimitbox.
function depthlimitbox_Callback(hObject, eventdata, handles)

if get(hObject,'Value')  %returns toggle state of limit on hs check box
    handles.RUNspec.wave.limit = 'Depth';
    % Unable selection of the other variable
    set(handles.UserDefined,'enable','off');    
    set(handles.Hsmax_box,'enable','off');
        
elseif ~get(hObject,'Value')
    set(handles.UserDefined,'enable','on');
    set(handles.Hsmax_box,'enable','on');
    
end
% Update handles structure
guidata(hObject, handles);

% READ SLOPE
function BetaText_Callback(hObject, eventdata, handles)
handles.RUNspec.wave.beta = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure

% --- Executes during object creation, after setting all properties.
function BetaText_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% READ PERIOD
function TwaveText_Callback(hObject, eventdata, handles)
handles.RUNspec.wave.Twave = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure


% --- Executes during object creation, after setting all properties.
function TwaveText_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%  READ DEPTH 
function DepthText_Callback(hObject, eventdata, handles)
handles.RUNspec.wave.depth = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure

% --- Executes during object creation, after setting all properties.
function DepthText_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%---------------------------------------------------------------------
%                              (4) MCMC
%---------------------------------------------------------------------
% SET NUMBER OF ITERATIONS
function iterationsText_Callback(hObject, eventdata, handles)
handles.RUNspec.maxIT = str2double(get(hObject,'String'));  % Read
guidata(hObject, handles);                                  % Update handles structure

% --- Executes during object creation, after setting all properties.
function iterationsText_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% SET NUMBER OF CHAINS
function ChainText_Callback(hObject, eventdata, handles)
handles.RUNspec.Nchain = str2double(get(hObject,'String')); % read
guidata(hObject, handles);                                  % Update handles structure


% --- Executes during object creation, after setting all properties.
function ChainText_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% BURN IN
function BurninText_Callback(hObject, eventdata, handles)
handles.RUNspec.brn = str2double(get(hObject,'String'));    % read
guidata(hObject, handles);                                  % Update handles structure

% --- Executes during object creation, after setting all properties.
function BurninText_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
%                          (5)  SET RETURN PERIOD 
% --------------------------------------------------------------------
function RPtext_Callback(hObject, eventdata, handles)
handles.RUNspec.RP = str2double(get(hObject,'String'));     % read
guidata(hObject, handles);                                  % Update handles structure

% --- Executes during object creation, after setting all properties.
function RPtext_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%-----------------------------------------------------------------
%                                    (6)   RUN
%-----------------------------------------------------------------
% --- Executes on button press in runpush.
function runpush_Callback(hObject, eventdata, handles)

% CHECK OBS
if isempty(handles.OBS)
    msgbox({'NO DATA SELECTED'});
end

% CHECK distribution
if isempty(handles.RUNspec.DISTR.Type)
    msgbox({'DISTRIBUTION TYPE NOT SELECTED'});
end

if strcmp(handles.RUNspec.DISTR.Type,'GP')
    if isempty(handles.RUNspec.Utype)
        msgbox({'THRESHOLD TYPE NOT SELECTED'});
    end
end

% CHECK Hs Limit
if isempty(handles.RUNspec.wave.limit)
    msgbox({'WAVE LIMIT NOT SELECTED'});
end

% RUN if Everything is given as input
if isempty(handles.OBS) ||...
        isempty(handles.RUNspec.wave.limit) ||...
        isempty(handles.RUNspec.DISTR.Type)
    return
else    
    % Save observations
    OBS = handles.OBS;    
    % Save RUNspec from user
    RUNspec = handles.RUNspec;
    
    RUNspec.DISTR.Model = 'Stat';
    % Additional info on prior (bigger prior domain)
    switch RUNspec.DISTR.Type
        case {'GEV'} 

            % DO NOT EDIT
            % 'Uniform': parm1 = min   | parm2 = max
            % 'Uniform': parm1 = mean  | parm2 = std

            % Location - MU(GEV): 
            RUNspec.PRIOR.MUdistr = 'Normal'; 
            RUNspec.PRIOR.MUparm1 = mean(OBS);
            RUNspec.PRIOR.MUparm2 = std(OBS);

            % Scale - SI(GEV):
            RUNspec.PRIOR.SIdistr = 'Uniform';  
            RUNspec.PRIOR.SIparm1 = 0;
            RUNspec.PRIOR.SIparm2 = 3;

            % Shape - XI(GEV):
            RUNspec.PRIOR.XIdistr = 'Uniform'; 
            RUNspec.PRIOR.XIparm1 = -2; 
            RUNspec.PRIOR.XIparm2 =  2;

            RUNspec.NS.MU = 'none';
            RUNspec.NS.SI = 'none';
            RUNspec.NS.XI = 'none';
            
        case {'GP'}

            %  DO NOT EDIT PRIOR
            % 'Uniform' : parm1 = min  | parm2 = max

            % Scale
            RUNspec.PRIOR.SIdistr = 'Uniform';
            RUNspec.PRIOR.SIparm1 = 0;
            RUNspec.PRIOR.SIparm2 = 3;

            % Shape
            RUNspec.PRIOR.XIdistr = 'Uniform'; 
            RUNspec.PRIOR.XIparm1 = -2; 
            RUNspec.PRIOR.XIparm2 = 2; 

            % DO NOT EDIT

            RUNspec.NS.MU = 'none';
            RUNspec.NS.SI = 'none';
            RUNspec.NS.XI = 'none';

            % RUNspec.THtype: (i) 'Const' (Do not edit)
            RUNspec.THtype = 'Const';
    end
    
    % Additional info on plot and results 
    EXTRAS.PlotRL  = 'Y';   % Plot Return period
    EXTRAS.saveRES = 'Y';  % Save results
    
    %-----------> RUN ProNEVAwave
    save('USER_INPUT.mat', 'OBS','RUNspec', 'EXTRAS');      % Save all parameters
    close('ProNEVAwave_GUI');                                % Close current GUI

    load( 'currentDIR.mat');                                 % Change directory
    cd(currentDIR);
    cd('ProNEVAwavepackage');                                % Open Folder w/ ProNEVA                    
    save( 'currentDIR.mat','currentDIR' );                   % Store main director to be able to go back

    % --------------------- RUN ProNEVA -----------------------------------
    ProNEVAwave(OBS, RUNspec, EXTRAS)      
   
    
end
