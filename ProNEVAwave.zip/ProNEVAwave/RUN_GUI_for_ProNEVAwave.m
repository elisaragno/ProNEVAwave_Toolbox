%-------------------------------------------------------------------------
%                           RUN ProNEVAwave
%-------------------------------------------------------------------------
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Disclaimer:} The Process-informed Nonstationary Extreme Value Analysis-Wave
%(ProNEVAwave) software package is provided `as is' without any endorsement
%made and without warranty of any kind, either express or implied. While
%we strive to ensure that ProNEVA is accurate, no guarantees for the
%accuracy of the codes, output information and figures are made.
%ProNEVAwave
%codes and outputs can only be used at your own discretion and risk and
%with agreement that you will be solely responsible for any damage and that
%the authors and their affiliate institutions accept no responsibility for errors or omissions
%in ProNEVAwave codes, outputs, figures, and documentation. In no event shall
%the authors, developers or their affiliate institutions be liable to you
%or any third parties for any special, direct, indirect or consequential
%damages and financial risks of any kind, or any damages whatsoever,
%resulting from, arising out of or in connection with the use of ProNEVAwave.
%The user of ProNEVAwave agrees that the codes and algorithms are subject to
%change without notice.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Erease previous messages
clc;

currentDIR = pwd();                     % Current Directory     
cd('GUIpackageProNEVAwave');                   % Open Folder w/ GUIs
save('currentDIR.mat', 'currentDIR');    % Save Original Directory 

ProNEVAwave_GUI;                   % Run GUI

% add default values for prior and parameters
% threshold GP

