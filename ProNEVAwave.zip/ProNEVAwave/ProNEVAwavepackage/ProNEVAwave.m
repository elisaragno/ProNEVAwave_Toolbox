function ProNEVAwave(OBS, RUNspec, EXTRAS)

% Total Number of Observations
RUNspec.Nobs = length(OBS); 

%--------------------------------------------------------------------------
% DISTRIBUTION TYPE: GEV/GP
% -------------------------------------------------------------------------
% RUNspec.DISTR.Type
% (1) RUNspec.DISTR.Type = 'GEV'     Generalized Extreme Value Distribution
% (2) RUNspec.DISTR.Type = 'GP'      Generalized Pareto Distribution

% In the case of GP - assign threshold
if strcmp(RUNspec.DISTR.Type, 'GP')
    
    switch RUNspec.THtype
        
        case 'Const'
            switch RUNspec.Utype
                case {'Th'}
                    % check p in [0 1]
                    if RUNspec.THp <= 0 || RUNspec.THp > 1
                        disp('Invalide quantile');
                        return
                    end
                    % Extrapolate peaks based on quantile selected and the distance between
                    % consecutive peaks
                    RUNspec.u = quantile(OBS, RUNspec.THp); %Threshold based on entire obs
            end
            
            % findpeaks(data) returns a vector with the local maxima (peaks) of the input signal vector 
            [PKS, idxPKS] = findpeaks(OBS,...
                            'MinPeakHeight', RUNspec.u,...
                            'MinPeakDistance',RUNspec.MinPeaksDist);  
            % Number of peaks
            RUNspec.Npks  = length(PKS);            
            % Index of the excesses
            RUNspec.IDX_Yex = idxPKS;
            % Yex are threshold excess conditioned on X > u
            Yex = PKS - RUNspec.u;
            % Total Excesses above threshold 
            RUNspec.TotNex  = sum(OBS > RUNspec.u);
    end
   
    % Number of excesses
    RUNspec.Nex  = length(Yex);                   

    % Number of Years
    RUNspec.Nyears = round( RUNspec.Nobs/RUNspec.NobsY);
    
    % Probability of exceess
    RUNspec.Fu = RUNspec.Nex/RUNspec.Nobs;
    % RUNspec.Fu = RUNspec.TotNex/RUNspec.Nobs;
    
    % Store entire original data set in RUNspec structure
    RUNspec.OBS = OBS;
    
    % Store Exceses
    RUNspec.Yex = Yex;
        
end

% Vector X for MannKendall and White Test
if strcmp(RUNspec.DISTR.Type, 'GP')
    RUNspec.COV.X  = (1 : length(Yex))';          
else 
    RUNspec.COV.X   = (1 : length(OBS))';   
end

%----------------------------------------------------------------------
% DIMENSIONALITY OF THE PROBLEM
%----------------------------------------------------------------------
if strcmp(RUNspec.DISTR.Model, 'NonStat')
    
    f = errordlg('work in progress','Message');
    return
    
end

if strcmp(RUNspec.DISTR.Model, 'Stat')
    
    switch RUNspec.DISTR.Type
        
        case { 'GEV' }
            RUNspec.Dim = 3;
        case 'GP'
            RUNspec.Dim = 2;          
            
    end
    
end


switch RUNspec.wave.limit
    case 'Depth'
        %--------------------------------------------------------------------------
        % Hs (significant wave heights) boundaries
        % [REF] Kamphuis, J. W. "Incipient wave breaking." Coastal Engineering 15.3 (1991): 185-203. - Eq (12)
        %--------------------------------------------------------------------------
        Cw         = RUNspec.wave;      % read wave characteristics
        [Ldepth,~] = shoal(Cw.Twave, Cw.depth);

        RUNspec.wave.Hs_mxmx = (0.095.*exp(4.*(tand(Cw.beta)))*tanh(((2*pi.*Cw.depth)./Ldepth))).*Ldepth;
        RUNspec.wave.gamma   = RUNspec.wave.Hs_mxmx/Cw.depth;
        RUNspec.wave.Ldepth  = Ldepth;
        
end
% Upper bound should be smaller than the max observations
switch RUNspec.DISTR.Type

    case { 'GEV' }
        RUNspec.wave.Hs_mxmn = max(OBS);
    case 'GP'
        RUNspec.wave.Hs_mxmn = max(Yex) +  RUNspec.u;          

end
% in case of distribution type without upper bound, the max Hs 
% has a return period equal to T_Hs_mxmx (arbitrary value)
RUNspec.wave.T_Hs_mxmx = 10000;

%-------------------------------------------------------------------
% Joint distribution (xi,si): Prior
%------------------------------------------------------------------- 
si1  = RUNspec.PRIOR.SIparm1;
si2  = RUNspec.PRIOR.SIparm2;

% domain si
sid  = (si1 + 0.001) : 0.001 : si2; 
xi1  = RUNspec.PRIOR.XIparm1;
xi2  = RUNspec.PRIOR.XIparm2; 

% domain xi - split positive(p) and negative(n) --> check domain only for
% xi=0 values
xi_n = -0.0001: -0.001 : xi1;
xi_p = 0.0001 : 0.001 : xi2;

% All pairs in the domain
[XIn, SIn] = meshgrid(xi_n, sid);	% negative xi
[XIp, SIp] = meshgrid(xi_p, sid);	% positive xi

XI = [XIn(:); XIp(:)];
SI = [SIn(:); SIp(:)];

RUNspec.wave.domain = [XI, SI];

switch RUNspec.DISTR.Type
    
    case 'GP'
        
        RUNspec.rpGP = RUNspec.wave.T_Hs_mxmx.*RUNspec.NobsY*RUNspec.Fu;
        
        hmu0_p = (SIp(:)./XIp(:)).*(RUNspec.rpGP.^XIp(:) - 1);
        hmu0_n = (SIn(:)./XIn(:)).*(RUNspec.rpGP.^XIn(:) - 1);
        % hmu0_n = -SIn(:)./XIn(:);

        hmu0   = [hmu0_n; hmu0_p];

        % Calculate probability of success:        

        idx_min = hmu0 <= (RUNspec.wave.Hs_mxmn - RUNspec.u);
        idx_max = hmu0 >= (RUNspec.wave.Hs_mxmx - RUNspec.u);        

        hmu0(idx_min) = NaN;
        hmu0(idx_max) = NaN;

        pSUCC = sum(~isnan(hmu0))/length(hmu0);    
        RUNspec.wave.pSUCC = pSUCC;
        
    case 'GEV'
        % Flat prior on the XI,SI domain (finite domain)
        % the joint density function has finite integrale but not
        % normalized
        RUNspec.wave.pSUCC = 0.02;
        
end

%--------------------------------------------------------------------------
% PARAMETER ESTIMATION - MCMC
%--------------------------------------------------------------------------

disp('SOLVE MCMC')
switch RUNspec.DISTR.Type
    case { 'GEV'}
        disp('case GEV')
        [OUT, RUNspec] = MCMC(OBS, RUNspec);
    case 'GP'
        disp('case GP')
        [OUT, RUNspec] = MCMC(Yex, RUNspec);
end

% Save only chains after burn in period
OUT.CH = OUT.CH(:,:, RUNspec.brn + 1 : end );

OUT.RhatCH = CONVERGENCE(OUT.CH(:,1:end-2,:));

% Warning if there is no convergence
if sum( OUT.RhatCH >= 1.2 ) ~= 0
    disp('Poor Convergence (R > 1.2)');
    disp('Try:');
    disp('change priors');
    disp('re-run MCMC');
    disp('increase n. of iterations');
    disp('increase n. of chains')
    return
elseif any( reshape( OUT.CH( : , end, : ), [], 1) == -Inf  ) || ...
       any( isnan( reshape( OUT.CH( : , end, : ), [], 1) ) ) || ...  
       any( reshape( OUT.CH( : , end, : ), [], 1) ==  Inf  )
   disp(' Invalid Posterior Values');
   return
end

% Reshape 3D array in a 2D array
% row: N_chains * N_iteration after burn-in
% col: Parameters | LogLikelihood | Posterior
% Parameters in order : xi; log(si); mu
OUT.CH = reshape( permute( OUT.CH, [ 2 1 3 ] ), size( OUT.CH, 2 ), [] )';

% Save Parameters
switch RUNspec.DISTR.Type

    case { 'GEV'}

        OUT.param.XI = OUT.CH(:,1);
        OUT.param.SI = exp( OUT.CH(:, 2 ) );
        OUT.param.MU = OUT.CH(:, 3);
      
    case { 'GP'}

        OUT.param.XI = OUT.CH(:,1);
        OUT.param.SI = exp( OUT.CH(:, 2 ) );
end

%--------------------------------------------------------------------------
% DIAGNOSTIC
%--------------------------------------------------------------------------
disp('DIAGNOSTIC')

switch RUNspec.DISTR.Type
    case { 'GEV'}
        [OUT, DGN] = DIAGNOSTIC(OBS, OUT, RUNspec);

    case 'GP'
        [OUT, DGN] = DIAGNOSTIC(Yex, OUT, RUNspec);
end

%--------------------------------------------------------------------------
% PLOT
%--------------------------------------------------------------------------

if strcmp( EXTRAS.PlotRL, 'Y' )

    disp('PLOTS')
    if strcmp(RUNspec.DISTR.Type, 'GP') % Test applied to the excess
        % RETURN LEVELS BASED ON DIFFERENT APPROCHES
        [ OUT ] = PLOTS(Yex, OUT, RUNspec);
        % PREDICTIVE DISTRIBUTION
        [PDFhat, Zhat] = PREDICTIVEpdf(Yex, OUT, RUNspec);
    else
        % RETURN LEVELS BASED ON DIFFERENT APPROCHES
        [ OUT ] = PLOTS(OBS, OUT, RUNspec);
        % PREDICTIVE DISTRIBUTION
        [PDFhat, Zhat] = PREDICTIVEpdf(OBS, OUT, RUNspec);
    end

end


% -------------------------------------------------------------------------
% SAVE RESULTS
% -------------------------------------------------------------------------
load('currentDIR.mat');

if strcmp(EXTRAS.saveRES, 'Y')
    
    SAVEresults(OBS, RUNspec, OUT, DGN, currentDIR);

end

end

%% Wave length - shoaling effect
function [l,cf,cg,ar,sf] = shoal(t,d)
    % INPUT:
    % t: wave period
    % d: water depth
    % OUTPUT:
    % determina: l,cf,cg,ar=tgh(kd)=c/c0,sf=sqrt(cg0/cg)
    % l: wave length
    
    g   = 9.81;
    c   = [.00011,.00039,.00171,.00654,.02174,.06320,.16084,.35550,.66667,1];
    sg  = (pi+pi)./t;
    c0  = g./sg;
    k0d = sg.*d./c0;
    kd  = sqrt(k0d.*k0d + k0d./polyval(c,k0d));
    ar  = k0d./kd;
    sf  = ar+kd.*(1-ar.*ar);
    cf  = c0.*ar;
    l   = cf.*t;
    cg  = 0.5.*c0.*sf;
    sf  = 1./sqrt(sf);%shoaling factor
end 




 


