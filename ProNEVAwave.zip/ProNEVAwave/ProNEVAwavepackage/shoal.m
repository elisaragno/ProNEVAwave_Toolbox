%% Wave length - shoaling effect
function [l,cf,cg,ar,sf] = shoal(t,d)
    % INPUT:
    % t: wave period
    % d: water depth
    % OUTPUT:
    % determina: l,cf,cg,ar=tgh(kd)=c/c0,sf=sqrt(cg0/cg)
    % l: wave length
    
    g   = 9.81;
    c   = [.00011,.00039,.00171,.00654,.02174,.06320,.16084,.35550,.66667,1];
    sg  = (pi+pi)./t;
    c0  = g./sg;
    k0d = sg.*d./c0;
    kd  = sqrt(k0d.*k0d + k0d./polyval(c,k0d));
    ar  = k0d./kd;
    sf  = ar+kd.*(1-ar.*ar);
    cf  = c0.*ar;
    l   = cf.*t;
    cg  = 0.5.*c0.*sf;
    sf  = 1./sqrt(sf);%shoaling factor
end 