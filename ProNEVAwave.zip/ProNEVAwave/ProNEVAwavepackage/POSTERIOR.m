%--------------------------------------------------------------------------
% POSTERIOR DISTRIBUTION 
%--------------------------------------------------------------------------

function [OUT] = POSTERIOR(Z, DATA, RUNspec)

% D: problem dimensionality
% Z: structure w/ proposed parameters
% DATA: observations

% [OUT] = [ POSTERIOR PDF | MAX LIKELIHOOD ] 

C = size(Z,1);          % number of chains

% Initialize matrices 
logPST = -inf*ones(C,1);    % Log Posterior 
logLK  = -inf*ones(C,1);    % Log Likelihood

% Check Validity GP
checkGP  = @(Y, xi, si) ( 1 + xi.*(Y./si) ) > 0 ;

% Check Validity GEV 
checkGEV = @(Y, xi, si, mu) ( 1 + xi.*(Y - mu)./si ) > 0 ;


switch RUNspec.DISTR.Type
%--------------------------------------------------------------------------    
%   CASE GEV distribution - xi, si, mu   
%--------------------------------------------------------------------------    
    case { 'GEV'} 
        L = RUNspec.Nobs;      % Length data
            
        % GEV: exp( -(1 + (xi/si)*(x-mu))^(-1/xi) ) defined for: (1 + xi(data-mu)/sigma) > 0
        
        % Posterior for each chain
        for i = 1 : C

            switch RUNspec.DISTR.Model
                
                case 'Stat'
                    
                    xi = repmat( Z(i,1), L, 1); 
                    si = exp( repmat( Z(i,2), L, 1 ) );
                    mu = repmat( Z(i,3), L, 1 );
                
            end
            
            % GEV
            if strcmp(RUNspec.DISTR.Type, 'GEV')
                check   = checkGEV( DATA, xi, si, mu ) > 0 ;
                checkXI = xi < 1/2 ;
                
                if sum(check) == L && sum( checkXI ) == L
                    
                    [PR] = PRIORwave( RUNspec, Z(i, :));                    % Prior
                    LK   = gevpdf(DATA, xi, si, mu);                    % Likilihood
                    
                    logLK(i,1)  = sum( log( LK ) );                     % Log Likelihood
                    logPST(i,1) = logLK(i,1) + sum( log( PR ) );        % Posterior 

                end
            end

        end
        
        [ OUT ] = [ logLK, logPST ] ;
        
%--------------------------------------------------------------------------    
%   CASE GP distribution - xi, si    
%--------------------------------------------------------------------------                
    case 'GP'
        
        L = RUNspec.Nex;    % Number of Excess
        
        % p = gpcdf(X,k,sigma,theta) : Prob of X
        % k tail index (shape) | sigma: scale | theta: threshold (location) 
        % Posterior for each chain
        for i = 1 : C

            switch RUNspec.DISTR.Model
                
                case 'Stat'
                    
                    xi = Z(i,1); 
                    si = exp( Z(i,2) );
                                  
            end
 
            check = checkGP( DATA, xi, si ) > 0 ;
            
            if sum(check) == L
                 
                [PR] = PRIORwave( RUNspec, Z( i,: ) );              % Prior 
                LK   = gppdf(DATA, xi, si, 0);                  % Likelihood ( GP thr = 0, DATA == Excesses)  
                
                logLK(i,1)  = sum( log( LK ) );                 % Log Likelihood
                logPST(i,1) = logLK(i,1) + sum( log( PR ) );	% Posterior 
            end

        end
        
        [ OUT ] = [ logLK, logPST ];
end
end
