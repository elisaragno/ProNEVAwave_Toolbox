%--------------------------------------------------------------------------
%                                 PLOT ProNEVA                            %
%--------------------------------------------------------------------------
function [ OUT ] = PLOTS(OBS, OUT, RUNspec)

% Define the covariates for the plots if non stationary model. Otherwise,
% only one plot

% Plot Return Level
[ OUT ] = returnLEVEL( OBS, OUT, RUNspec );



end


%--------------------------------------------------------------------------
%                       RETURN LEVEL CURVES                               %
% Ref [1]: Coles 2001. An introduction to statistical modeling of extreme
% value
%--------------------------------------------------------------------------
function [ OUT ] = returnLEVEL( OBS, OUT, RUNspec )

% OBS: observations
% OUT: parameter estimates
% RUNspec: info about the model
% RLplot: Info about the plot

% Stat case
nVC  = 1;

%--------- Load Dimension of the problem and estimated parameters ---------

D   = RUNspec.Dim;                  % Problem Dimension
CH  = OUT.CH( :, 1:D);              % Sets of Parameter
PST = OUT.CH( :, end);              % Log - Posterior

%------------------- Find set of parameters w/ maximum Posterior ---------- 

[ idxMAX, ~ ] = find( PST == max( PST ), 1, 'last');    % Location Maximum LogPosterior

%----------------------- Vector of Return Periods ------------------------- 

TT  = ( 2 : RUNspec.RP )';              % Vector of RP including value of ~1
p   = 1 - 1./TT;                     % Probability associated w/ R


% ------------------------------- Extract Parameters ----------------------
switch RUNspec.DISTR.Type
    
    %----------------------------- GEV ----------------------------- 
    case { 'GEV'}       
        % Define vectors mu, si, xi ------------------
        switch RUNspec.DISTR.Model
            
            case 'Stat'  
                
                mu = repmat( CH( :, 3), 1, nVC ) ;
                si = repmat( exp( CH( :, 2) ), 1, nVC ) ;
                xi = repmat( CH( :, 1), 1, nVC ) ;
            
        end
        
        OUT.PARvc(:, 1, 1:nVC) = xi;
        OUT.PARvc(:, 2, 1:nVC) = si;
        OUT.PARvc(:, 3, 1:nVC) = mu;
        
        % ---------------------- RETURN LEVEL ------------------------
           
        r  = size( mu, 1 );                 % Number sets
        
        RLmax = zeros( length(p), nVC);     % Initialize matrix
        RLmin = zeros( length(p), nVC);     % Initialize matrix 
        
        if strcmp( RUNspec.DISTR.Type, 'GEV' )
            QTLfunc = @( p, xi, si, mu) gevinv( p, xi, si, mu );
        end
            
        for i = 1 : nVC

            temp = zeros(r, length(p) );

            for j = 1 : r
                temp( j, : ) =  QTLfunc( p, xi( j , i ), si( j , i ), mu( j , i ) );
            end

            OUT.RLplot.RL95(:,i)  = quantile(temp, .95)';
            OUT.RLplot.RL05(:,i)  = quantile(temp, .05)';
            OUT.RLplot.RL50(:,i)  = quantile(temp, .50)';
            OUT.RLplot.RLm (:,i)  = temp(idxMAX, :)';

            % For Shaded Area 
            RLmin(:,i) = min(temp);
            RLmax(:,i) = max(temp);

        end
        clear temp   
    %----------------------- Generalized Pareto ---------------------------    
    case 'GP'        
        %------------------- Define vectors  si, xi -----------------------
        switch RUNspec.DISTR.Model
            case 'Stat'
                si = exp( CH( :, 2) );
                xi = CH( :, 1);
            
        end
        
        OUT.PARvc(:, 1, 1:nVC) = xi;
        OUT.PARvc(:, 2, 1:nVC) = si;
        
        % RUNspec.NobsY: number of observations in one year: RUNspec.NobsY
        % RUNspec.Fu:= RUNspec.Nex/RUNspec.Nobs Probability of exceess 

        pGP = TT.*RUNspec.NobsY*RUNspec.Fu;

        U = RUNspec.u  ;
     
        r  = size( si, 1 );                 % Number sets
        RLmax = zeros( length(p), nVC);     % Initialize matrix
        RLmin = zeros( length(p), nVC);     % Initialize matrix 
        
        for i = 1 : nVC

            temp = zeros(r, length(p) );

            for j = 1 : r
                % Ref[1] page 81
                temp( j, : ) =  U(i) + si(j,i)/xi(j,i)*( pGP.^xi( j,i ) - 1 );
            end

            OUT.RLplot.RL95( :,i )  = quantile(temp, .95)';
            OUT.RLplot.RL05( :,i )  = quantile(temp, .05)';
            OUT.RLplot.RL50( :,i )  = quantile(temp, .50)';
            OUT.RLplot.RLm ( :,i )  = temp(idxMAX, :)';

            % For Shaded Area 
            RLmin( :,i ) = min(temp);
            RLmax( :,i ) = max(temp);

        end
        clear temp        
end
%--------------------------------------------------------------------------
%                           EMPIRICAL CDF                                 %
%--------------------------------------------------------------------------
switch RUNspec.DISTR.Type
    case 'GP'
        % CDF based on Weibull formula
        % x  = sort(RUNspec.OBS);
        x  = sort(RUNspec.Yex + RUNspec.u);
        
        for ix = 1:length(x)
            fx(ix) = sum( x <= x(ix) )/( length(x) + 1 );
        end
        
        % Tx = ( 1./( 1 - fx ) )./ ( RUNspec.NobsY );
        Tx = ( 1./( 1 - fx ) )./ ( RUNspec.Nex/( RUNspec.Nobs/RUNspec.NobsY) );
                
%         % Alternative way: built-in ECDF function (uncomment also lines 533-534) 
%         [fx, x] = ecdf(RUNspec.OBS);                                 % ECDF entire data
%         Tx = ( 1./( 1 - fx ( 1 : end-1 ) ) )./ ( RUNspec.NobsY );    % Removed fx = 1;
        
    case 'GEV'
        
        % CDF based on Weibull formula
        x  = sort(OBS);
        
        for ix = 1:length(x)
            fx(ix) = sum( x <= x(ix) )/( length(x) + 1 );
        end
        
        Tx = ( 1./( 1 - fx ) );
        
        
%         % Alternative way: built-in ECDF function (uncomment also lines 533-534)
%         [fx, x] = ecdf(OBS);
%         Tx = 1./(1-fx(1:end-1));    % Removed fx = 1;
        
end

% % Uncomment in case built-in ECDF is choosen
% x  = x( 1 :end-1 );
 
%--------------------------------------------------------------------------
%                           PLOT RETURN LEVEL                             %
%--------------------------------------------------------------------------
for f = 1 : nVC
    
    figure;
    hold on
    box on
    grid on
%     % Shaded Grey area
%     mcmc = fill( [ log10(TT') log10(fliplr( TT')) ],  [ RLmax( :, f )' fliplr( RLmin( :, f )' ) ],...
%         [.9 .9 .9], 'EdgeColor', 'none', 'FaceAlpha', .5);

    % MPE RL
    hRLmpe = plot( log10(TT), OUT.RLplot.RLm( :, f ), '--', 'Color', [.3 .3 .3], 'LineWidth', 1.5 );

    % Median RL
    hRL50 = plot(  log10(TT), OUT.RLplot.RL50( :, f ), '-', 'Color', [.8 0 0], 'LineWidth', 1.5 );

    % 90% CI
    hCI(1) = line(  log10(TT), OUT.RLplot.RL05( :, f ) );
    hCI(2) = line(  log10(TT), OUT.RLplot.RL95( :, f ) );


    set( hCI, 'LineStyle', '-.', 'Color', [0 .5 0], 'LineWidth', 1.7)

    % Add labels
    hTitle = title('Return Level: Stationary Case');
    
    hXLabel = xlabel( 'Return Period' );
    hYLabel = ylabel( 'Return Level' );

    % Empirical CDF
    try
        hObs = scatter( log10(Tx), x, 25, 'MarkerEdgeColor',[0 0 .8],'MarkerEdgeAlpha', .4,...
                  'MarkerFaceColor',[0 0 1], 'MarkerFaceAlpha', .4, 'LineWidth',1);
    catch
        hObs = scatter( log10(Tx), x, 25, 'MarkerEdgeColor',[0 0 .8],...
            'MarkerFaceColor',[0 0 1],'LineWidth',1);
    end
    
    % Plot Hmax
    hmax_plt = yline(RUNspec.wave.Hs_mxmx,'Color', [0, 0.4118, 0.5804], 'LineWidth', 1.7 );
    
     hLegend = legend([hObs, hRLmpe, hRL50, hCI(1),hmax_plt], ...
    'Data', 'MLE','Median', '90% CI','H_{max}',...
    'Location', 'northeast');

    % Adjust font
    set(gca, 'FontName', 'Helvetica', 'FontSize', 14)
    set(hLegend, 'FontSize', 12, 'FontName', 'Helvetica', 'TextColor',[.3 .3 .3])
    set([hXLabel, hYLabel], 'FontSize', 14)
    set(hTitle, 'FontSize', 14, 'color',[.3 .3 .3], 'fontweight', 'normal')

    % Adjust axes properties
    set(gca, 'TickDir', 'in', 'TickLength', [.02 .02], ...
        'XMinorTick', 'on', 'YMinorTick', 'on',...
        'XColor', [.3 .3 .3], 'YColor', [.3 .3 .3], 'LineWidth', 1, ...
         'Xtick',  ( log10( [2 10 20 50 100 ])), 'Xticklabel', {'2' '10' '20' '50' '100'} );
     
    xlim([log10(TT(1)) log10( TT(end) ) ]);
    ylim([ OUT.RLplot.RL05( 1, f ) 1.1*RUNspec.wave.Hs_mxmx]);
     
%    xticks( log10( [2 10 20 50 100 ]) );
%    xticklabels( {'2' '10' '20' '50' '100'} );
end

end

