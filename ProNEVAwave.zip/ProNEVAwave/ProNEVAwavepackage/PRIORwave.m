%--------------------------------------------------------------------------
% PRIOR DISTRIBUTION 
%--------------------------------------------------------------------------

function [PR] = PRIORwave(RUNspec, Z)

% RUNspec:  Info about distributions and waves
% RUNspec.wave.domain = [XI, SI]; 
% Z: one set of parameters - number of columns depend on the type of analysis 

% Assumption prior GEV case: p(teta) = p(MU)*p(SI,XI|MU)

% Boundaries Hs - absolute values 
hsmax = RUNspec.wave.Hs_mxmx;
hsmin = RUNspec.wave.Hs_mxmn;

switch RUNspec.DISTR.Type
%--------------------------------------------------------------------------    
%   CASE GEV distribution - xi, si, mu   
%--------------------------------------------------------------------------    
    case { 'GEV'}
        % Position of the parameters
        idxM = 2;
        idxS = 1;
        
        % LOCATION (MU)
        mu1 = RUNspec.PRIOR.MUparm1;
        mu2 = RUNspec.PRIOR.MUparm2;
        mu  = Z(1, idxM + 1);

        switch RUNspec.PRIOR.MUdistr
            case 'Normal';  pMU = normpdf(mu, mu1, mu2);
        end
        
        % JOINT PRIOR SCALE(SI) AND SHAPE (XI) given MU
        % Proposed values from MCMC
        si  = exp( Z(1, idxS + 1) );
        xi  = Z(1, 1);        
        
        % h_max based on the proposed set of parameters
        pmax       = 1-1/RUNspec.wave.T_Hs_mxmx;
        temp_hmax  = gevinv(pmax, xi, si, mu );
        
        if  xi <= ( RUNspec.PRIOR.XIparm2 ) && xi >= (RUNspec.PRIOR.XIparm1) &&... 
                si<= ( RUNspec.PRIOR.SIparm2 ) && si>= ( RUNspec.PRIOR.SIparm1 )

            if temp_hmax <= hsmax && temp_hmax >= hsmin

                    pXISI = RUNspec.wave.pSUCC;
                else
                    pXISI = eps;

            end
        else
            pXISI = eps;
        end
        
        % Prior
        
        PR = [ pXISI pMU ];
         
%--------------------------------------------------------------------------    
%   CASE GP distribution - xi, si    
%--------------------------------------------------------------------------        
    case 'GP'
        
        idxS = 1;
        si  = exp( Z(1, idxS + 1) ); 
        xi  = Z(1, 1);
 
        if  xi <= ( RUNspec.PRIOR.XIparm2 ) && xi >= (RUNspec.PRIOR.XIparm1) && si<= ( RUNspec.PRIOR.SIparm2 ) && si>= ( RUNspec.PRIOR.SIparm1 )
            if xi > 0            
                % maximum Hs based on the proposed set of parameters 
                temp_hmax = (si./xi).*(RUNspec.rpGP.^xi - 1);            
            else
                temp_hmax = -si./xi;
            end

            % assign probability to xi amd si
            if temp_hmax <= ( hsmax - RUNspec.u ) && temp_hmax >= (hsmin - RUNspec.u)

                pXISI = RUNspec.wave.pSUCC;
            else
                pXISI = eps;
            end
        else
            pXISI = eps;
        end

end
        % Prior
        
        PR = [pXISI];
        
end
     
